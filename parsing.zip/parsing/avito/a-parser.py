import requests
from bs4 import BeautifulSoup
import time  # Модуль для работы со значением времени
import datetime  # Модуль для работы с датой
import sqlite3


connect = sqlite3.connect('avito.db')
cursor = connect.cursor()

cursor.execute('''
    CREATE TABLE if not exists s340(
        id varchar(15),
        title varchar(80),
        price varchar(10),
        link varchar(160)
        )
    ''')

def getPage(link, table):
    cursor.execute('''
        CREATE TABLE if not exists tmp_ad(
            id varchar(15),
            title varchar(80),
            price varchar(10),
            link varchar(160)
            )
    ''')

    req = requests.get(link)
    bs = BeautifulSoup(req.text, 'html.parser')
    all_items = bs.find_all('div', class_ = 'iva-item-root-_lk9K')
    for item in all_items:
        cursor.execute('INSERT INTO tmp_ad (id, title, price, link) values (?,?,?,?)',
            [
            item['id'],
            item.find('h3', class_ = 'title-root-zZCwT').text,
            (item.find('span', class_ = 'text-size-s-BxGpL').text).replace('\xa0', ''),
            'https://www.avito.ru/' + item.find('a', class_ = 'link-link-MbQDP')['href']
            ]
        )

    cursor.execute('''
        CREATE TABLE if not exists new_ad(
            id varchar(15),
            title varchar(80),
            price varchar(10),
            link varchar(160)
            )
    ''')

    cursor.execute(f'''
        INSERT INTO new_ad (id, title, price, link)            
        SELECT
            t1.id, t1.title, t1.price, t1.link
        FROM tmp_ad t1
        LEFT JOIN {table} t2
        on t1.id = t2.id
        WHERE t2.id is null
    ''')
    
    cursor.execute('SELECT * FROM new_ad')
    for row in cursor.fetchall():
        send_telegram(row[0] + '\n' + row[1] + '\n' + row[2] + '\n' + row[3])
    
    cursor.execute(f'''
        INSERT INTO {table} (id, title, price, link)            
        SELECT
            id, title, price, link
        FROM new_ad
    ''')
    connect.commit()

    cursor.execute('DROP TABLE tmp_ad')
    cursor.execute('DROP TABLE new_ad')


def send_telegram(text: str):
    token = "1999999996:AAEygffghgfhjghfjfghjfghjfghjfghjjgowK7M"  # токен моего бота в телеграме
    url = "https://api.telegram.org/bot"
    channel_id = "999999999"  # мой личный id в телеграме
    url += token
    method = url + "/sendMessage"
 
    r = requests.post(method, data={
         "chat_id": channel_id,
         "text": text
          })
 
    if r.status_code != 200:
        raise Exception("post_text error")

getPage('https://www.avito.ru/moskva/noutbuki/lenovo-ASgCAQICAUCo5A0U5tlm?bt=1&q=s340&s=104', 's340')


#     print('Поиск новых вакансий завершен', str(datetime.datetime.now()))
#     time.sleep(600)
