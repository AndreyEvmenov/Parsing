# Библиотека для работы с HTTP-запросами. Будем использовать ее для обращения к API HH
import requests
# Пакет для удобной работы с данными в формате json
import json
# Модуль для работы со значением времени
import time
# Модуль для работы с датой
import datetime


def getPage(page=0):
    """
    Создаем метод для получения страницы со списком вакансий.
    Аргументы:
        page - Индекс страницы, начинается с 0. Значение по умолчанию 0, т.е. первая страница
    """

    # Справочник для параметров GET-запроса
    params = {
        'text': 'NAME:Системный%20администратор',  # Текст фильтра. В имени длжно быть слово "Системный%20администратор"
        'employment': 'part',
        'area': 1,  # Поиск ощуществляется по вакансиям города Москва
        'page': page,  # Индекс страницы поиска на HH
        'per_page': 100  # Кол-во вакансий на 1 странице
    }

    req = requests.get('https://api.hh.ru/vacancies', params)  # Посылаем запрос к API
    data = req.content.decode()  # Декодируем его ответ, чтобы Кириллица отображалась корректно
    req.close()
    return data


def send_telegram(text: str):
    token = "1999999996:AAEygffghgfhjghfjfghjfghjfghjfghjjgowK7M"  # токен моего бота в телеграме
    url = "https://api.telegram.org/bot"
    channel_id = "999999999"  # мой личный id в телеграме
    url += token
    method = url + "/sendMessage"

    r = requests.post(method, data={
         "chat_id": channel_id,
         "text": text
          })

    if r.status_code != 200:
        raise Exception("post_text error")


while True:
    # считываем страницу
    # Преобразуем текст ответа запроса в справочник Python
    jsObj = json.loads(getPage())
    # Создаем новый документ, записываем в него ответ запроса, после закрываем
    f = open('./docs/pagination/parsedinfo.json', mode='w', encoding='utf8')
    f.write(json.dumps(jsObj, ensure_ascii=False))
    f.close()

    # Необязательная задержка, но чтобы не нагружать сервисы hh, оставим. 5 сек мы может подождать
    # time.sleep(0.25)


    # Открываем файл, читаем его содержимое, закрываем файл
    f = open('./docs/pagination/parsedinfo.json', encoding='utf8')
    jsonText = f.read()
    f.close()

    # Преобразуем полученный текст в объект справочника
    jsonObj = json.loads(jsonText)

    # Получаем и проходимся по непосредственно списку вакансий
    for v in jsonObj['items']:

        f = open('./docs/ids/vacancies.json', encoding='utf8')
        jsonID = f.read()
        if v['id'] not in jsonID:
            f = open('./docs/ids/vacancies.json', mode='a', encoding='utf8')
            print('New vacancy detected - ', v['id'])
            f.write(v['id'])
            f.write(v['url'])
            send_telegram('Есть новая вакансия:')
            tmessage = 'https://khimki.hh.ru/vacancy/' + v['id']
            send_telegram(tmessage)
            f.close()
        f.close()

    print('Поиск новых вакансий завершен', str(datetime.datetime.now()))
    time.sleep(600)
